"""
data_cleaning.py — Load and clean the IBM Telco Churn dataset.

Steps:
  1. Load raw CSV
  2. Drop customerID (not predictive)
  3. Fix TotalCharges whitespace → float (11 rows affected)
  4. Impute the resulting NaNs with median
  5. Encode target: Yes → 1, No → 0
  6. Strip whitespace from all string columns
  7. Save cleaned CSV to data/telco_clean.csv

Usage:
    python src/data_cleaning.py
"""

import pandas as pd
import numpy as np
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
from config import RAW_CSV, CLEAN_CSV, TARGET, ID_COL, NUMERIC_COLS


def load_raw(path: Path) -> pd.DataFrame:
    """Load raw CSV and perform sanity checks."""
    print(f"[1/6] Loading raw data from: {path}")
    df = pd.read_csv(path)
    print(f"      Shape: {df.shape}  |  Columns: {df.columns.tolist()}")
    return df


def drop_id(df: pd.DataFrame) -> pd.DataFrame:
    """Remove the ID column — not a predictive feature."""
    print(f"[2/6] Dropping ID column: '{ID_COL}'")
    return df.drop(columns=[ID_COL], errors="ignore")


def fix_total_charges(df: pd.DataFrame) -> pd.DataFrame:
    """
    TotalCharges is read as object because some rows contain ' ' (space).
    Convert to float; the 11 space-only rows become NaN.
    """
    print("[3/6] Fixing TotalCharges dtype (whitespace → NaN → median impute)")
    df = df.copy()
    df["TotalCharges"] = pd.to_numeric(
        df["TotalCharges"].astype(str).str.strip(), errors="coerce"
    )
    n_null = df["TotalCharges"].isna().sum()
    if n_null:
        median_val = df["TotalCharges"].median()
        df["TotalCharges"] = df["TotalCharges"].fillna(median_val)
        print(f"      Imputed {n_null} NaN(s) with median={median_val:.2f}")
    return df


def encode_target(df: pd.DataFrame) -> pd.DataFrame:
    """Encode Churn: Yes → 1, No → 0."""
    print(f"[4/6] Encoding target '{TARGET}': Yes→1 / No→0")
    df = df.copy()
    df[TARGET] = df[TARGET].map({"Yes": 1, "No": 0}).astype(int)
    churn_rate = df[TARGET].mean()
    print(f"      Churn rate: {churn_rate:.1%}  ({df[TARGET].sum()} positives)")
    return df


def strip_strings(df: pd.DataFrame) -> pd.DataFrame:
    """Strip leading/trailing whitespace from all object columns."""
    print("[5/6] Stripping whitespace from string columns")
    str_cols = df.select_dtypes("object").columns
    df[str_cols] = df[str_cols].apply(lambda s: s.str.strip())
    return df


def validate(df: pd.DataFrame) -> None:
    """Quick validation assertions before saving."""
    print("[6/6] Running validation checks")
    assert df.isnull().sum().sum() == 0,   "Unexpected NaNs remain!"
    assert df[TARGET].isin([0, 1]).all(),  "Target has values outside {0,1}!"
    assert df["TotalCharges"].dtype == float, "TotalCharges must be float!"
    n_dupes = df.duplicated().sum()
    if n_dupes:
        print(f"      WARNING: {n_dupes} duplicate rows detected")
    print("      All checks passed.")


def clean(raw_path: Path = RAW_CSV, out_path: Path = CLEAN_CSV) -> pd.DataFrame:
    """Full cleaning pipeline. Returns the clean DataFrame."""
    df = load_raw(raw_path)
    df = drop_id(df)
    df = fix_total_charges(df)
    df = encode_target(df)
    df = strip_strings(df)
    validate(df)

    out_path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(out_path, index=False)
    print(f"\n✓ Clean data saved → {out_path}  ({df.shape[0]} rows, {df.shape[1]} cols)\n")
    return df


if __name__ == "__main__":
    clean()

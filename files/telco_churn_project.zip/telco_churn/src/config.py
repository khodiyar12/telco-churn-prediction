"""
config.py — Central configuration for the Telco Churn project.
Edit paths and settings here; everything else imports from this file.
"""
from pathlib import Path

# ── Paths ─────────────────────────────────────────────────────────────────────
ROOT        = Path(__file__).resolve().parent.parent
DATA_DIR    = ROOT / "data"
OUTPUT_DIR  = ROOT / "outputs"
MODEL_DIR   = ROOT / "models"

RAW_CSV     = DATA_DIR / "WA_Fn-UseC_-Telco-Customer-Churn.csv"
CLEAN_CSV   = DATA_DIR / "telco_clean.csv"

# ── Target & ID ───────────────────────────────────────────────────────────────
TARGET      = "Churn"
ID_COL      = "customerID"

# ── Feature groups ────────────────────────────────────────────────────────────
NUMERIC_COLS = [
    "tenure", "MonthlyCharges", "TotalCharges",
]

BINARY_COLS = [
    "gender", "SeniorCitizen", "Partner", "Dependents",
    "PhoneService", "PaperlessBilling",
]

MULTI_CAT_COLS = [
    "MultipleLines", "InternetService", "OnlineSecurity",
    "OnlineBackup", "DeviceProtection", "TechSupport",
    "StreamingTV", "StreamingMovies", "Contract", "PaymentMethod",
]

CATEGORICAL_COLS = BINARY_COLS + MULTI_CAT_COLS

# ── Modelling ─────────────────────────────────────────────────────────────────
RANDOM_STATE = 42
TEST_SIZE    = 0.20
CV_FOLDS     = 5
SCORING      = "roc_auc"

# LightGBM Optuna search space
LGBM_PARAM_SPACE = {
    "n_estimators":   (200, 1200),
    "learning_rate":  (0.01, 0.15),
    "num_leaves":     (20,  150),
    "max_depth":      (3,   10),
    "min_child_samples": (10, 80),
    "subsample":      (0.6, 1.0),
    "colsample_bytree": (0.5, 1.0),
    "reg_alpha":      (1e-4, 10.0),
    "reg_lambda":     (1e-4, 10.0),
}
OPTUNA_TRIALS = 60
